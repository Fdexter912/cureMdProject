import { Component } from '@angular/core';
import { AddStdntService } from 'src/app/StudentServices/add-stdnt.service';

@Component({
  selector: 'app-student-list',
  templateUrl: './student-list.component.html',
  styleUrls: ['./student-list.component.css']
})
export class StudentListComponent {
  stdnts: any;
  constructor(private AddStdntsService : AddStdntService){}
  
  ngOnInit(): void {
    this.AddStdntsService.getStdnts().subscribe((data: any) => {
      this.stdnts = data;
      console.log(this.stdnts);
    });
  }
}
