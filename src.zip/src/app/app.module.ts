import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AddStudentComponent } from './StudentComponents/add-student/add-student.component';
import { UpdateStudentComponent } from './StudentComponents/update-student/update-student.component';
import { DeleteStudentComponent } from './StudentComponents/delete-student/delete-student.component';
import { StudentListComponent } from './StudentComponents/student-list/student-list.component';
import { AddCourseComponent } from './CourseComponents/add-course/add-course.component';
import { UpdateCourseComponent } from './CourseComponents/update-course/update-course.component';
import { DeleteCourseComponent } from './CourseComponents/delete-course/delete-course.component';
import { CourseListComponent } from './CourseComponents/course-list/course-list.component';
import { HttpClientModule } from '@angular/common/http';


@NgModule({
  declarations: [
    AppComponent,
    AddStudentComponent,
    UpdateStudentComponent,
    DeleteStudentComponent,
    StudentListComponent,
    AddCourseComponent,
    UpdateCourseComponent,
    DeleteCourseComponent,
    CourseListComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
