import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AddStdntService {
  constructor(private http: HttpClient) {}
  private apiUrl = "https://localhost:44329/api/Student";
  addStudents(studentData: any): Observable<any> {
    const addStudentUrl = `${this.apiUrl}/AddStudent`; // Adjust the URL for your API

    // Send an HTTP POST request to add a student
    return this.http.post(addStudentUrl, studentData);
  }

  getStdnts(): Observable<any> {
    return this.http.get(this.apiUrl + '/GetAllStudents');
  }



  

}
