import { TestBed } from '@angular/core/testing';

import { AddStdntService } from './add-stdnt.service';

describe('AddStdntService', () => {
  let service: AddStdntService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(AddStdntService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
