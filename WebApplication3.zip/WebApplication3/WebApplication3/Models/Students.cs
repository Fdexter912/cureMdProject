﻿namespace WebApplication3.Models
{
    public class Students
    {
        public int Student_ID { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public int Age { get; set; }
        public int CourseID { get; set; }
    }
}
