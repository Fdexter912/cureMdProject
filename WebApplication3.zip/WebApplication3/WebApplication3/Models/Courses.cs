﻿namespace WebApplication3.Models
{
    public class Courses
    {
        public int CourseID { get; set; }
        public string CourseName { get; set; }

    }
}
