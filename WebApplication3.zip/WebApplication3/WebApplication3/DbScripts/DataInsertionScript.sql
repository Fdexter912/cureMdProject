----Insert into Courses
INSERT INTO Courses(CourseName)
VALUES
       ( 'English'),
       ( 'Urdu'),
       ( 'Maths'),
       ( 'Physics'),
       ( 'Chemistry');
	   Go

----Insert into Courses
INSERT INTO Students (FirstName,LastName,Age,CourseID)
VALUES 
       ( 'Maham', 'Ali', 30, 1),
       ( 'Fahad', 'Ahmed',40, 2),
       ( 'Iqbal', 'Hasan',35, 3),
       ( 'Ali', 'Bilal', 30, 4),
       ( 'Zain', 'Ahmed',40 ,5 ),
       ( 'Ahmed', 'Hammad',35, 4),
       ( 'Izza', 'Awais', 30, 3),
       ( 'Kulsoom', 'Junaid',40, 2),
       ( 'Nida', 'Ahsaan',35, 1),
       ( 'Ahad', 'Adnan',35,5);
	  Go